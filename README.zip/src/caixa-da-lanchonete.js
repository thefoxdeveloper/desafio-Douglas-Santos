class CaixaDaLanchonete {
  constructor() {
    this.cardapio = {
      cafe: { descricao: "Café", valor: 3.0 },
      chantily: { descricao: "Chantily (extra do Café)", valor: 1.5 },
      suco: { descricao: "Suco Natural", valor: 6.2 },
      sanduiche: { descricao: "Sanduíche", valor: 6.5 },
      queijo: { descricao: "Queijo (extra do Sanduíche)", valor: 2.0 },
      salgado: { descricao: "Salgado", valor: 7.25 },
      combo1: { descricao: "1 Suco e 1 Sanduíche", valor: 9.5 },
      combo2: { descricao: "1 Café e 1 Sanduíche", valor: 7.5 },
    };

    this.formasPagamento = ["dinheiro", "debito", "credito"];
  }

  calcularValorDaCompra(metodoDePagamento, itens) {
    if (itens.length === 0) {
      console.log("Não há itens no carrinho de compra!");
      return;
    }

    let metodo = metodoDePagamento;
    let total = 0;
    let itensRecebidos = itens.map((x) => x.split(","));

    let itensPrincipais = [];

    for (let i = 0; i < itensRecebidos.length; i++) {
      let codigoItem = itensRecebidos[i][0];
      let quantidade = Number(itensRecebidos[i][1]);

      if (!this.cardapio[codigoItem]) {
        console.log("Item inválido: " + codigoItem);
        return;
      }

      if (isNaN(quantidade) || quantidade === 0) {
        console.log("Quantidade inválida para o item: " + codigoItem);
        return;
      }

      let itemCardapio = this.cardapio[codigoItem];

      let subtotal = itemCardapio.valor * quantidade;
      total += subtotal;
    }

    if (this.formasPagamento.includes(metodo)) {
      if (metodo === "dinheiro") {
        total *= 0.95;
      } else if (metodo === "credito") {
        total *= 1.03;
      }
      console.log("R$ " + total.toFixed(2));
    } else {
      console.log("Forma de pagamento inválida!");
    }
  }
}

// Exemplo de uso
new CaixaDaLanchonete().calcularValorDaCompra("dinheiro", [
  "cafe,1",
  "chantily,1",
]);

new CaixaDaLanchonete().calcularValorDaCompra("credito", []); // Não há itens no carrinho de compra!
